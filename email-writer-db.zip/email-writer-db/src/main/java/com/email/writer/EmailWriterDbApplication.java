package com.email.writer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailWriterDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailWriterDbApplication.class, args);
	}

}
